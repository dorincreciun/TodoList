import {PageLayout} from "../../../shared/layouts/PageLayout";

export const MessagePage = () => {
    return (
        <PageLayout>MessagePage</PageLayout>
    )
}