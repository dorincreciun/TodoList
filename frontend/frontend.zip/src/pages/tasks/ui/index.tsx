import {PageLayout} from "../../../shared/layouts/PageLayout";

export const TasksPage = () => {
    return (
        <PageLayout>TasksPage</PageLayout>
    )
}