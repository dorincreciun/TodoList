import {PageLayout} from "../../../../shared/layouts/PageLayout";

export const LoginPage = () => {
    return (
        <PageLayout>
            d
        </PageLayout>
    )
}