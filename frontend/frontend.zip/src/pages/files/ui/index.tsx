import {PageLayout} from "../../../shared/layouts/PageLayout";

export const FilesPage = () => {
    return (
        <PageLayout>FilesPage</PageLayout>
    )
}