export {SidebarAuth as default} from './ui'
export {useAuthSidebar} from './model/useAuthSidebar'